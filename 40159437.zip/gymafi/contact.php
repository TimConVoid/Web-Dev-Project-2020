<?php
session_start();
if (!isset($_SESSION['user_products'])) {
    header("location: login.php");
} 

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];


    $mailaddress = "tconway08@qub.ac.uk";
    $headers = "From $email:";
    $txt = "You have recieved an email from ".$name."\n\n".$message;

    mail($mailaddress,"TriMax Queries",$txt, $headers );
    

    echo "Email sent. Click <a href='index.php'>here</a> to go back.";
    
}

?>