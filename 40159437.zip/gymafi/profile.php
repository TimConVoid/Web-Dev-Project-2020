<?php
session_start();

include("conn.php");

if (!isset($_SESSION['user_products'])) {
    header('location:login.php');
}

$userid = $_SESSION['user_products'];
$insert = "SELECT * FROM user_accounts WHERE id = '$userid'";
$result = $conn->query($insert);

if (!$result) {
    echo $conn->error;
}
while ($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $id = $row['id'];
}



?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TriMax</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link href="styles/bootstyle.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/mystyles.css">
</head>

<body>


<!--Navigation bar-->
<nav class="navbar navbar-expand-md navbar-light mynav sticky-top" <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><img id="mylogo" src="imgs/triLogo4.jpg"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="index.php">
            <h3><strong>Tri</strong>max</h3>
        </a>
        <div class="collapse navbar-collapse" id="navbarResponsive">

            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="events.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php#contact">Contact Us</a>
                </li>

                <?php


                if (isset($_SESSION['user_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='profile.php'>My Profile</a>
                        <a class='dropdown-item' href='messages.php'>Messages</a>
                        <a class='dropdown-item' href='myplan.php'>My Plan</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </div>
                </li>";
                } elseif (isset($_SESSION['admin_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='admin/dash.php'>Dashboard</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </li>";
                } else {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                        </a>
                        <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='login.php'>Login</a>
                        <a class='dropdown-item' href='register.php'>Register</a>
                        </li>";
                }



                ?>


            </ul>
        </div>


        </div>
        </div>


    </nav>




    <div class="container">
        <div class="row welcome text-center" id="myprofile1">
            <div class="col-12">
                <?php


                echo "<h2 class='display-4'>Welcome $name</h2>
                        <a href='editprofile.php' class='btn btn-outline-secondary'>Edit Profile</a>";





                ?>
                <!--
                <h2 class="display-4">Get started</h2>
                
                echo "<a href='myplan.php?clientid=$id' class='btn btn-primary btn-lg active' role='button' 
            aria-disabled='true'>My Plan</a>
            <a href='tracker.php'><button type='button' class='btn btn-lg'>Activity Tracker</button></a>";
            -->


            </div>
        </div>
    </div>
   <!-- <div class="container-fluid padding">
        <div class="row welcome text-center">
            <div class="col-12">
                <h1 class="display-4">Applications</h1>
            </div>
            <h1>
                <div class="col-12" style="padding-left:30px; padding-right:30px;" >
                    <p class="lead">
                        Before we can begin sending you training plans and other additional information
                        regarding events etc. you must first send off an application.
                        It's really simple; we just need a few additional details about you and then
                        you'll soon be on your way! Remember to include any medical conditions or
                        special requirements in your application form that you think we should be aware of.
                        Once your application is sent off, we will have it checked and should respond within
                        24 hours. Once we have approved your application, you will have access to some awesome
                        features including our activity tracker and your activity plan which will be updated accordingly
                        to your goals and current fitness levels. Cool right? Get applying now!
                    </p>
                </div>
            </h1>

        </div>
            -->

    <div class="container-fluid padding">
        <div class="row padding">
            <div class="col-md-4">
                <div class="card">
                    <img class="card-img-top" src="imgs/apply.jpg">
                    <div class="card-body">
                        <h4 class='card-title'>Apply</h4>
                        <p class='card-text'>Send off an application today! Your application will be checked by the 
                            coach within 24hrs. Click below to send an application.
                        </p>
                        <a href='apply.php' class="btn btn-outline-secondary">Apply</a>
                    </div>
                </div>

            </div>
            <div class="col-md-4">
                <div class="card">
                    <img class="card-img-top" src="imgs/tracker.jpg">
                    <div class="card-body">
                        <h4 class='card-title'>Activity Tracker</h4>
                        <p class='card-text'>Once your application has been approved, you can use our quick and
                            easy activity tracker. Click below to record an activity.
                            </p>
                        <a href='tracker.php' class="btn btn-outline-secondary">Tracker</a>
                    </div>
                </div>

            </div>
            <div class="col-md-4">
                <div class="card">
                    <img class="card-img-top" src="imgs/plan4.jpg">
                    <div class="card-body">
                        <h4 class='card-title'>My Plan</h4>
                        <p class='card-text'>Your training plan is customised to suit you depending on your goals and 
                            fitness levels. Click below to see your current plan.
                            </p>
                            <?php
                            echo "<a href='myplan.php?clientid=$userid' class='btn btn-outline-secondary'>My Plan</a>";
                            ?>
                        
                    </div>
                </div>

            </div>
        </div>

    </div>

    



</body>