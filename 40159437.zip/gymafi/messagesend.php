<?php
    include("conn.php");
    session_start(); 

    if(isset($_SESSION['user_products'])){
        $id = $_SESSION['user_products'];
    } else{
        header("location: index.php");
    }
    $getname = "SELECT * FROM user_accounts WHERE id='$id'";
    $result2 = $conn->query($getname);
    if(!$result2){
        echo $conn->error;
    }
    while($row = $result2->fetch_assoc()){
        $name = $row['name'];
    }

    $date = "NOW()";
    $msg = $conn->real_escape_string($_POST['msg']);

    $insert = "INSERT INTO messages (client_id, date, message, client_name) VALUES 
                ('$id', $date,'$msg', '$name')";

    $result = $conn->query($insert);

    if(!$result){
        echo $conn->error;
    } else
    echo "<p>Message sent. Click <a href='profile.php'>here</a> to go back.";


?>