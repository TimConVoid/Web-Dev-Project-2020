<?php
session_start();
include("conn.php");

if (isset($_SESSION['user_products'])) {
    $clientid = $_SESSION['user_products'];
} else{
    header("location:index.php");
}

$read = "SELECT * FROM client_profiles WHERE client_id=$clientid";

$result = $conn->query($read);


if (!$result) {
    echo $conn->error;
}
$numrows = $result->num_rows;

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TriMax</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link href="styles/bootstyle.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/mystyles.css">
</head>

<body>


    <!--Navigation bar-->
    <nav class="navbar navbar-expand-md navbar-light mynav sticky-top" <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><img id="mylogo" src="imgs/triLogo4.jpg"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="index.php">
            <h3><strong>Tri</strong>max</h3>
        </a>
        <div class="collapse navbar-collapse" id="navbarResponsive">

            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="events.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php#contact">Contact Us</a>
                </li>

                <?php


                if (isset($_SESSION['user_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='profile.php'>My Profile</a>
                        <a class='dropdown-item' href='myplan.php'>My Plan</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </div>
                </li>";
                } elseif (isset($_SESSION['admin_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='admin/dash.php'>Dashboard</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </li>";
                } else {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                        </a>
                        <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='login.php'>Login</a>
                        <a class='dropdown-item' href='register.php'>Register</a>
                        </li>";
                }



                ?>


            </ul>
        </div>


        </div>
        </div>


    </nav>

    <div class="container-fluid padding">
        <div class="row welcome text-center">
            <div class="col-md-12">
                <a href='myactivities.php' class='btn btn-outline-secondary'>See Activities</a>
            </div>

        </div>
    </div>

        <div class="container-fluid padding">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4 track-form">
                    <div class="card">
                        <h1 class="text-center">Add New Activity</h1>
                        <div class="card-body">
                            <?php
                            if ($numrows == 0) {
                                echo "<h3>Your application must be approved before you can track activities.</h3>
                                    <p>Click <a href='profile.php'>here</a> to go back.";
                            } else {
                                echo " <form action='trackerprocess.php' method='POST' style = 'padding-left:10%; padding-right:10%; padding-top: 10%;'>
                            
                            <p>Sport: <select class = 'form-control' name='sport'>
                                <option>Swimming</option>
                                <option>Cycling</option>
                                <option>Running</option>
                            </select></p>
                            <p>Distance(km): <input type = 'number' class = 'form-control' placeholder='Distance(km)' name='distance'></p>
                            <p>Time(mins): <input type = 'number' class = 'form-control' placeholder='Time(mins)' name='time'></p>
                            <p>How did this activity feel?: <select class = 'form-control'  name='feel'>
                                <option>Easy</option>
                                <option>Moderate</option>
                                <option>Hard</option>
                            </select></p>
                            <p>Additional information: <textarea class = 'form-control' placeholder='addinfo' name='addinfo'></textarea></p>
                            <p><input type = 'submit' class='btnSubmit' value = 'Upload'</p>
    
                        </form>
                                    ";
                            }

                            ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--
    <div class="container-fluid padding applyform">
        <div class="row" style="height: 500px;">
            <div class="col-2"></div>
            <div class="col-8" id='applyform'>
                <?php /*
                    if ($numrows == 0){
                        echo "<h3 style='text-align: center;'>Your application must be approved before you can track activities.</h3>";
                    } else {
                        echo "<h3 style='text-align: center'>Track your activity</h3>
                        <p></p>
                        <form action='trackerprocess.php' method='POST' class='myform'>
        
                            <div class='form-group'>
                                <label for='sport'>
                                    <i>Select sport:</i>
                                </label>
                                <select name='sport'>
                                    <option>Swim</option>
                                    <option>Cycling</option>
                                    <option>Running</option>
                                </select>
        
                                <label for='distance'>
                                    <i>Distance(km):</i>
                                </label>
                                <input type='number' name='distance' placeholder='Distance(km)' id='distance' required>
        
                                <label for='time'>
                                    <i>Time(mins)</i>
                                </label>
                                <input type='number' name='time' placeholder='Time(mins)' id='time' required>
                            </div>
        
                            <div class='form-group'>
                                <label for='feel'>
                                    <i>How did it feel?:</i>
                                </label>
                                <select name='feel'>
                                    <option>Easy</option>
                                    <option>Moderate</option>
                                    <option>Hard</option>
                                </select>
        
        
        
        
        
                                <div class='row'>
                                    <div class='col-6'>
                                        <label for='addinfo'>Any additional information:</label>
                                    </div>
                                    <div class='col-6'>
                                        <textarea name='addinfo' placeholder='More info...' class='textarea'></textarea>
                                    </div>
                                </div>
        
                            </div>
                            <button type='submit'>Submit</button>
                        </form>
                                ";
                    }
                    */
                ?>


            </div>


        </div>
        <div class="col-2"></div>
    </div>
    -->
</body>