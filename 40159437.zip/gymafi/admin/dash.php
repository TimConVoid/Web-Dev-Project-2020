<?php
session_start();
include("../conn.php");

if (!isset($_SESSION['admin_products'])) {
  header('location:../login.php');
}



?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>TriMax</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
  <link href="styles/bootstyle.css" rel="stylesheet">
  <link rel="stylesheet" href="../styles/mystyles.css">
</head>

<body>
  
    <!--Navigation bar-->
    <nav class="navbar navbar-expand-md navbar-light mynav sticky-top" <div class="container-fluid">
        <a class="navbar-brand" href="../index.php"><img id="mylogo" src="../imgs/triLogo4.jpg"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="../index.php">
            <h3><strong>Tri</strong>max</h3>
        </a>
        <div class="collapse navbar-collapse" id="navbarResponsive">

            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="../events.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../index.php#contact">Contact Us</a>
                </li>

                <?php


                if (isset($_SESSION['user_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='profile.php'>My Profile</a>
                        <a class='dropdown-item' href='myplan.php'>My Plan</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </div>
                </li>";
                } elseif (isset($_SESSION['admin_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='dash.php'>Dashboard</a>
                        <a class='dropdown-item' href='../logout.php'>Logout</a>
                        </li>";
                } else {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                        </a>
                        <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='login.php'>Login</a>
                        <a class='dropdown-item' href='register.php'>Register</a>
                        </li>";
                }



                ?>


            </ul>
        </div>


        </div>
        </div>


    </nav>




  <div class="container padding">

    <h1 class="title">Admin Dashboard</h1>
    <div class="row">
      <div class='col-md-3'>
        <div class='card'>
          <div class='card-body'>
            <h2>Applications</h2>
            <p class='subtitle'>
              <?php

              $findapps = "SELECT * FROM user_applications";

              $resultapps = $conn->query($findapps);

              $numapps = $resultapps->num_rows;

              echo "<p>Number of applications: $numapps </p>";


              ?>
            </p>
          </div>
          <footer class='card-footer '>
            <a href='applications.php' class='card-footer-item'>Manage Applications</a>

          </footer>
        </div>
      </div>
      <div class='col-md-3'>
        <div class='card'>
          <div class='card-body'>
            <h2>Clients</h2>
            <p class='subtitle'>
              <?php
              $findclients = "SELECT * FROM client_profiles";

              $resultclients = $conn->query($findclients);

              $numclients = $resultclients->num_rows;

              echo "<p>Number of clients: $numclients </p>";


              ?>

            </p>
          </div>
          <footer class='card-footer '>
            <a href='manageclients.php' class='card-footer-item'>Manage Clients</a>

          </footer>
        </div>
      </div>

      <div class='col-md-3'>
        <div class='card'>
          <div class='card-body'>
            <h2>Calender</h2>
            <p class='subtitle'>
              <p>Check appointments.</p>
            </p>
          </div>
          <footer class='card-footer '>
            <a href='appointments.php' class='card-footer-item'>See calender</a>

          </footer>
        </div>
      </div>

      <div class='col-md-3'>
        <div class='card'>
          <div class='card-body'>
            <h2>Messages</h2>
            <p class='subtitle'>
              <?php
              $getmessages = "SELECT * FROM messages";
              $result = $conn->query($getmessages);
              $numrows = $result->num_rows;

              echo "<p>Number of messages: $numrows</p>";

              ?>
             
            </p>
          </div>
          <footer class='card-footer '>
            <a href='adminmessages.php' class='card-footer-item'>See my messages</a>

          </footer>
        </div>
      </div>

    </div>



  </div>
  <div class="container padding" style="padding-top: 30px">
    <div class="row padding">
      <div class="col-md-4"></div>
      <div class="col-md-4">
        <div class="card">
          <div class='card-body'>
            <h2>Events</h2>
            <p class='subtitle'>
              <p>Upload new events</p>
            </p>
          </div>
          <footer class='card-footer '>
            <a href='addevent.php' class='card-footer-item'>Add Event</a>

          </footer>
        </div>
        <div class="col-md-4"></div>
      </div>
    </div>
  </div>



</body>

</html>