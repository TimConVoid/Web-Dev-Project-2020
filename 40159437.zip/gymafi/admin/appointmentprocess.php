<?php
session_start();
include("../conn.php");

if (!isset($_SESSION['admin_products'])) {
    header('location:../login.php');
  }
$id=$_GET['clientid'];
$date = $conn->real_escape_string($_POST['date']);
$title = $conn->real_escape_string($_POST['title']);

$getusername = "SELECT * FROM user_accounts WHERE id = '$id'";

//echo $getusername;

$result = $conn->query($getusername);

if(!$result){
    echo $conn->error;
}

while ($row = $result->fetch_assoc()){
    $name = $row['name'];
}

$insertappointment = "INSERT INTO appointments (date, title, client_id) VALUES
                        ('$date', '$name:  $title', '$id')";
//echo $insertappointment;

$result2 = $conn->query($insertappointment);



if(!$result2){
    echo $conn->error;
} else {

    echo "Appointment added successfully. Click <a href='dash.php'>here</a> to return to the dashboard.";
}



?>