<?php
include("../conn.php");
session_start();
if (!isset($_SESSION['admin_products'])) {
    header('location:../login.php');
  }
$date = $conn->real_escape_string($_POST['date']);
$title = $conn->real_escape_string($_POST['title']);


$insertappointment = "INSERT INTO events (date, title) VALUES
                        ('$date', '$title')";
//echo $insertappointment;

$result2 = $conn->query($insertappointment);

if(!$result2){
    echo $conn->error;
} else {

    echo "Appointment added successfully. Click <a href='dash.php'>here</a> to return to the dashboard.";
}



?>