<?php
include("../conn.php");
session_start();
if (!isset($_SESSION['admin_products'])) {
    header('location:../login.php');
  }


$userid = $_GET['clientid'];


?>

<!DOCTYPE html>
<html>

<body>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>TriMax</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
        <link href="styles/bootstyle.css" rel="stylesheet">
        <link rel="stylesheet" href="../styles/mystyles.css">
    </head>

    
    <!--Navigation bar-->
    <nav class="navbar navbar-expand-md navbar-light mynav sticky-top" <div class="container-fluid">
        <a class="navbar-brand" href="../index.php"><img id="mylogo" src="../imgs/triLogo4.jpg"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="../index.php">
            <h3><strong>Tri</strong>max</h3>
        </a>
        <div class="collapse navbar-collapse" id="navbarResponsive">

            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="../events.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../index.php#contact">Contact Us</a>
                </li>

                <?php


                if (isset($_SESSION['user_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='profile.php'>My Profile</a>
                        <a class='dropdown-item' href='myplan.php'>My Plan</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </div>
                </li>";
                } elseif (isset($_SESSION['admin_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='dash.php'>Dashboard</a>
                        <a class='dropdown-item' href='../logout.php'>Logout</a>
                        </li>";
                } else {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                        </a>
                        <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='login.php'>Login</a>
                        <a class='dropdown-item' href='register.php'>Register</a>
                        </li>";
                }



                ?>


            </ul>
        </div>


        </div>
        </div>


    </nav>
    <div class="container login-container">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-md-6 login-form">
                <h1 id="myhead">Write a Message</h1>
                <?php
                echo "<form action='messageprocess.php?clientid=$userid' method='POST'>
                    <div class='form-group'>
                        <textarea name='msg' class='form-control' placeholder='Message' class='textarea' required></textarea>
                        </div>
                        <div class='form-group'>
                            <input type='submit' class='btnSubmit' value='Send' name='register'>
                        </div>
                </form>";
                ?>

            </div>
            <div class="col-3"></div>


        </div>
    </div>




</body>