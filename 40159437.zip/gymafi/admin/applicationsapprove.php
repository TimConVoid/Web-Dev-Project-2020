<?php
    include("../conn.php");
    session_start();
    if (!isset($_SESSION['admin_products'])) {
        header('location:../login.php');
      }
    
    $userid = $_GET['useid'];

    $appinsert = "SELECT user_applications.user_id, user_applications.dob, 
                    user_applications.weight, user_applications.actlevel, user_applications.sport, 
                    user_applications.description, user_accounts.email, 
                    user_accounts.name, user_accounts.phone 
                    FROM user_applications INNER JOIN user_accounts 
                    ON user_applications.user_id = user_accounts.id WHERE user_applications.user_id='$userid'";
    $result1 = $conn->query($appinsert);
    if(!$result1){
        echo $conn->error;
    }
    while ($row = $result1->fetch_assoc()){
        $clientname = $row['name'];
        $clientdob = $row['dob'];
        $clientweight = $row['weight'];
        $clientactlevel = $row['actlevel'];
        $clientsport = $row['sport'];
        $clientdesc = $row['description'];
        $clientemail = $row['email'];
        $clientphone = $row['phone'];
        $clientid = $row['user_id'];
    }


    $insertclient = "INSERT INTO client_profiles (name, dob, weight, actlevel, sport, description, email, phone, client_id)
                        VALUES ('$clientname','$clientdob','$clientweight','$clientactlevel','$clientsport',
                        '$clientdesc', '$clientemail', '$clientphone', '$clientid')";

    

    $result2 = $conn->query($insertclient);

    if(!$result2){
        echo $conn->error;
    }
                        

    $deleteapp = "DELETE FROM user_applications
        WHERE user_id='$userid'";
    
    $result3 = $conn->query($deleteapp);

    if(!$result3){
        echo $conn->error;
    }

    
    echo "<p>Application approved. Click <a href='applications.php'>here</a> to go back to applications.</p>";

?>