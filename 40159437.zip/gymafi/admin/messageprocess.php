<?php
include("../conn.php");
session_start();
if (!isset($_SESSION['admin_products'])) {
    header('location:../login.php');
  }
$clientid = $_GET['clientid'];
$msg = $conn->real_escape_string($_POST['msg']);
$date = "NOW()";

$insert = "INSERT INTO adminmessages (client_id, date, message) VALUES 
                ('$clientid',$date,'$msg') ";

$result = $conn->query($insert);

if(!$result){
    echo $conn->error;
} else{
    echo "<p>Message sent. Click <a href='dash.php'here</a> to go back.</p>";
}


?>