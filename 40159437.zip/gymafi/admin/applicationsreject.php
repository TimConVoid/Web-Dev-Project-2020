<?php
include("../conn.php");
session_start();
if (!isset($_SESSION['admin_products'])) {
    header('location:../login.php');
  }
  
    $userid = $_GET['useid'];

    $deleteapp = "DELETE FROM user_applications
        WHERE user_id='$userid'";
    
    $result3 = $conn->query($deleteapp);

    if(!$result3){
        echo $conn->error;
    }
    echo "<p>Application rejected. Click <a href='applications.php'>here</a> to go back to applications.</p>";

?>