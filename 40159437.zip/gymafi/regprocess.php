<?php
    session_start();

    include ("conn.php");

    $usernamedata = $conn->real_escape_string($_POST['username']);

    $passworddata = $conn->real_escape_string($_POST['password']);

    $emaildata = $conn->real_escape_string($_POST['email']);

    $namedata = $conn->real_escape_string($_POST['name']);

    $phonedata = $conn->real_escape_string($_POST['phone']);

    $addressdata = $conn->real_escape_string($_POST['address']);

    $time = "NOW()";


    $insertsql = "INSERT INTO user_accounts (username,password,email,name,phone,address,signup) 
                 VALUES ('$usernamedata','$passworddata','$emaildata','$namedata','$phonedata','$addressdata',$time)";

    $result = $conn->query($insertsql);

?>

<!DOCTYPE html>
<html>
 
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>TriMax</title>
 
</head>
<body>
<header>
 my list
</header>

 
<div class="row">
 
<?php
 
    if (!$result){
        echo $conn->error;
    }

    echo "Registered successfully.";

    $authuser = "SELECT * FROM user_accounts WHERE username='$usernamedata' AND password='$passworddata'";

    echo $authuser;

    $result2 = $conn->query($authuser);

    if(!$result2){
        echo $conn->error;
    }

    while($row = $result2->fetch_assoc()){
        $userid = $row['id'];
        echo $userid;
    
    }
    $_SESSION['user_products'] = $userid;

    
    

    header("location: profile.php");
 
       
?>    
 
</div>
       
</body>
</html>
