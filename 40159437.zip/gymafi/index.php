<?php
session_start();

if (isset($_SESSION['user_products'])) {
    $clientid = $_SESSION['user_products'];
}



?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TriMax</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link href="styles/bootstyle.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/mystyles.css">
</head>

<body>


    <!--Navigation bar-->
    <nav class="navbar navbar-expand-md navbar-light mynav sticky-top" <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><img id="mylogo" src="imgs/triLogo4.jpg"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="index.php">
            <h3><strong>Tri</strong>max</h3>
        </a>
        <div class="collapse navbar-collapse" id="navbarResponsive">

            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="events.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php#contact">Contact Us</a>
                </li>

                <?php


                if (isset($_SESSION['user_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='profile.php'>My Profile</a>
                        <a class='dropdown-item' href='myplan.php'>My Plan</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </div>
                </li>";
                } elseif (isset($_SESSION['admin_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='admin/dash.php'>Dashboard</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </li>";
                } else {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                        </a>
                        <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='login.php'>Login</a>
                        <a class='dropdown-item' href='register.php'>Register</a>
                        </li>";
                }



                ?>


            </ul>
        </div>


        </div>
        </div>


    </nav>


    <!--Image slider-->
    <div id="slides" class="carousel slide" data-ride="carousel" data-interval="10000">
        <ul class="carousel-indicators">
            <li data-target="#slides" data-slide-to="0" class="active"></li>
            <li data-target="#slides" data-slide-to="1"></li>
            <li data-target="#slides" data-slide-to="2"></li>

        </ul>

        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="imgs/swim.jpg" alt="Swim.">
                <div class="carousel-caption">
                    <h1 class="display-2 myhead"><strong>Tri</strong>max</h1>
                    <h3>Ready to crush your PB?</h3>





                </div>
            </div>
            <div class="carousel-item">
                <img src="imgs/bike3.jpg" alt="Cycle."">
                <div class=" carousel-caption">
                <h1 class="display-2 myhead"><strong>Tri</strong>max</h1>
                <h3>Unlock your true potential</h3>

            </div>
        </div>
        <div class="carousel-item" alt="Run.">
            <img src="imgs/run.jpg">
            <div class="carousel-caption">
                <h1 class="display-2 myhead"><strong>Tri</strong>max</h1>
                <h3>Break through the wall</h3>

            </div>
        </div>


    </div>


    </div>

    <!--Main-->
    <div class="container-fluid padding">
        <div class="row welcome text-center">
            <div class="col-12">
                <h1 class="display-4">Welcome</h1>
                <hr>

            </div>
        </div>
    </div>
    <div class="container-fluid padding">
        <div class="row text-center">
            <div class="col-md-12">
                <p class="lead">Whether you're a seasoned athlete or a first-timer, coach <strong>Joey Bloggs</strong> aims to get you to a place where you can crush your next triathalon PB.
                    Here at Trimax, we construct training plans suitable for you depending on your current fitness level and your goals. Interested? Keep scrolling to
                    see what we have to offer and why you should choose us if you're ready to exceed your own expectations!
                </p>
                <h3 class>Quick Links:</h3>
                <a href="register.php"><button type="button" class="btn btn-outline-dark btn-lg">Register</button></a>
                <a href="login.php"><button type="button" class="btn btn-outline-dark btn-lg">Login</button></a>
            </div>
        </div>


    </div>

    <div class="container-fluid padding">
        <div class="row welcome text-center">
            <div class="col-lg-12">
                <h1 class="display-4">About Me</h1>
                <hr>

            </div>
        </div>

    </div>
    <div class="container-fluid padding">
        <div class="row padding">
            <div class="col-md-6">

                <img src="imgs/coach2.jpg" class="img-fluid" style="width: 100%;">

            </div>
            <div class="col-lg-6">
                <p>Running is my passion. Swimming is my passion. Cycling is my passion. Triathlon is my life. Empowering, supporting and training others is my calling.
                    Since discovering the joy of exercise, sport and competition at an early age, I knew physical education was what I wanted to do .</p>
                <p>After school I attended
                    Limerick School of Physical Education and qualified as a Sports Coach with an honours degree in 2008. I went on to study Nutrition at Queens University Belfast
                    and subsequently obtained a Diploma in Personal Motivation and Training from Jordanstown University.
                    Following two years teaching with world class figures in Personal Training in Vancouver, Canada, I returned to my native County Down to establish my own training,
                    motivation and competition business.I have, to date, trained and assisted over one thousand people of varying ages and abilities to either start from zero to
                    achieve high levels of personal fitness or to push from a high fitness level to reach levels of endurance sport success.</p>
                <p> I have particularly focused on Triathlon
                    events throughout Ireland and the UK and count myself as one of the most successful and dedicated personal achievement motivators in the British Isles.</p>

            </div>
        </div>
    </div>


    <div class="container-fluid padding">
        <div class="row welcome text-center">
            <div class="col-lg-12">
                <h1 class="display-4">Breakdown</h1>
                <hr>

            </div>
        </div>

    </div>



    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="jumbotron runbit">
                    <div class="jumbotron swimblock">
                        <h2 class='sport-head'>Swim.</h2>

                    </div>
                    <p class="lead sport-info">
                        Whether you are a seasoned long-distance year- round
                        swimmer or have just started to dip your toe into the water, we can guide
                        you and help you to improve your performance. We have a wealth of experience in
                        motivational fitness and specific event training and have access to sportsmen and women
                        who are more than willing to share their experiences of swim training.
                </div>
            </div>
            <div class="col-md-4">
                <div class="jumbotron runbit">
                    <div class="jumbotron bikeblock">
                        <h2 class='sport-head'>Bike.</h2>

                    </div>
                    <p class="lead sport-info">
                        We have experience in cycle training both as a Single Event and as
                        part of Triathlon Competition. We have mapped local routes and
                        challenging altitude endeavours, all with an eye on excitement, safety
                        and personal achievement. No matter what your age, shape, gender or level
                        of fitness now, we will take you through all stages from starting out to
                        ratcheting up those miles.
                    </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="jumbotron runbit">
                    <div class="jumbotron runblock">
                        <h2 class='sport-head'>Run.</h2>

                    </div>
                    <p class="lead sport-info">
                        Running is where I started and the joy of long distance and hill
                        running brought me to endurance combination events particularly
                        the Triathlon. Fitness levels achieved through running can transfer
                        relatively easily to Swimming and Cycling and while all three disciplines
                        require specific weight training and muscle development, running is
                        undoubtedly the best all-round body trainer event.
                    </p>

                </div>

            </div>

        </div>
    </div>



    <footer>
        <div class="container-fluid padding">
            <div class="row text-center">
                <div class="col-md-6">
                    <h1 class="display-4">Get in touch</h1>
                    <p class="lead"><strong>Email:</strong> joeybloggs@email.com</p>
                    <hr>
                    <p class="lead"><strong>Phone:</strong> 0276278226336</p>
                    <hr>
                    <p class="lead"><strong>Address:</strong> 24 Imaginary Place</p>

                </div>
                <div class="col-md-6">
                    <h1 class="display-4">Send an Email</h1>

                    <form id='contact' class="contact-form" action="contact.php" method="post">

                        <div class="form-group">
                            <input type="text" class='form-control' name="email" placeholder="Email" id="email" required>
                        </div>
                        <div class="form-group">
                            <input type="name" class="form-control" name="name" placeholder="Full Name" id="name" required>
                        </div>
                        <div class="form-group">
                            <textarea name="message" class="form-control" placeholder="Message" class="textarea" required></textarea>
                        </div>
                        <div class='form-group'>
                            <input type="submit" class="btnSubmit form-control" name="submit" value="Send">
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </footer>




</body>

</html>