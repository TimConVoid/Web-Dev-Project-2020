<?php
session_start();
include("conn.php");

if (isset($_SESSION['user_products'])) {
    $clientid = $_SESSION['user_products'];
} else{
    header("location:index.php");
}

$read = "SELECT * FROM activity_tracker WHERE client_id=$clientid ORDER BY date DESC";

$result = $conn->query($read);


if (!$result) {
    echo $conn->error;
}
$numrows = $result->num_rows;

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TriMax</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link href="styles/bootstyle.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/mystyles.css">
</head>

<body>


   <!--Navigation bar-->
   <nav class="navbar navbar-expand-md navbar-light mynav sticky-top" <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><img id="mylogo" src="imgs/triLogo4.jpg"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="index.php">
            <h3><strong>Tri</strong>max</h3>
        </a>
        <div class="collapse navbar-collapse" id="navbarResponsive">

            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="events.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php#contact">Contact Us</a>
                </li>

                <?php


                if (isset($_SESSION['user_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='profile.php'>My Profile</a>
                        <a class='dropdown-item' href='myplan.php'>My Plan</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </div>
                </li>";
                } elseif (isset($_SESSION['admin_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='admin/dash.php'>Dashboard</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </li>";
                } else {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                        </a>
                        <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='login.php'>Login</a>
                        <a class='dropdown-item' href='register.php'>Register</a>
                        </li>";
                }



                ?>


            </ul>
        </div>


        </div>
        </div>


    </nav>

    <div class="container">

        <?php

        if($numrows==0){
            echo "<h4 class='text-center'> No activities</h4>";
        }else {

        while ($row = $result->fetch_assoc()) {
            $sport = $row['sport'];
            $distance = $row['distance'];
            $time = $row['time'];
            $feel = $row['feel'];
            $addinfo = $row['addinfo'];
            $date = $row['date'];


            echo  "<div class = 'row padding' style='padding-top: 30px;'>
                    <div class='col-md-2'></div>
                    <div class='col-md-8'>
                    <div class='card'>
                    <div class='card-body'>
                    <h3 class = 'card-title text-center'>$date</h3>
                    <p>Sport:   $sport</p>
                    <p>Distance:   $distance</p>
                    <p>Time:   $time</p>
                    <p>How it felt:   $feel</p>
                    <p>Additional info: $addinfo</p>
                    </div>
                    </div>
                    </div>
                    </div>
                    <div class='col-md-2'></div>
                    </div>";
        }

    }
        ?>

    </div>
</body>

</html>