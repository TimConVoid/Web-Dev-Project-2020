<?php
 
 
$user = "tconway08";
$pw = "SnzLSKMWZxT2Bq4L";
$server = "tconway08.lampt.eeecs.qub.ac.uk";
$db = "tconway08";
 
$conn = new mysqli($server, $user, $pw, $db);
 
 
if($conn->connect_error){
    echo $conn->connect_error;
}
 
 
?>