<?php

session_start();
    include("conn.php");

    $userid = $_SESSION['user_products'];
    $sport = $conn->real_escape_string($_POST['sport']);
    $distance = $conn->real_escape_string($_POST['distance']);
    $time = $conn->real_escape_string($_POST['time']);
    $feel = $conn->real_escape_string($_POST['feel']);
    $addinfo = $conn->real_escape_string($_POST['addinfo']);
    $date = "NOW()";
    

   

   $insertactivity = "INSERT INTO activity_tracker (client_id, sport, distance, time, feel,addinfo, date)
                        VALUES ('$userid', '$sport', '$distance', '$time', '$feel','$addinfo' ,$date)";

    $result = $conn->query($insertactivity);

    

    if (!$result){
        echo $conn->error;
    }

    echo "<p>Activity logged. Click <a href='profile.php'>here</a> to return to your profile.</p>";


?>