<?php

session_start();

include("conn.php");

if (!isset($_SESSION['user_products'])) {
    header("location: login.php");
}

$id = $_SESSION['user_products'];

$getappointments = "SELECT * FROM appointments WHERE client_id='$id'";

$result = $conn->query($getappointments);

if (!$result) {
    echo $conn->error;
}



$read = "SELECT * FROM upload_plan WHERE client_id=$id";

$result2 = $conn->query($read);


if (!$result2) {
    echo $conn->error;
}
$numrows = $result2->num_rows;



?>



<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TriMax</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link href="styles/bootstyle.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/mystyles.css">
    <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js" integrity="sha256-t8GepnyPmw9t+foMh3mKNvcorqNHamSKtKRxxpUEgFI=" crossorigin="anonymous"> </script>
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
    <link rel="stylesheet" href="styles/theme3.css" />
</head>

<body>
<!--Navigation bar-->
<nav class="navbar navbar-expand-md navbar-light mynav sticky-top" <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><img id="mylogo" src="imgs/triLogo4.jpg"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="index.php">
            <h3><strong>Tri</strong>max</h3>
        </a>
        <div class="collapse navbar-collapse" id="navbarResponsive">

            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="events.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php#contact">Contact Us</a>
                </li>

                <?php


                if (isset($_SESSION['user_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='profile.php'>My Profile</a>
                        <a class='dropdown-item' href='myplan.php'>My Plan</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </div>
                </li>";
                } elseif (isset($_SESSION['admin_products'])) {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                      </a>
                      <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='admin/dash.php'>Dashboard</a>
                        <a class='dropdown-item' href='logout.php'>Logout</a>
                        </li>";
                } else {
                    echo "<li class='nav-item dropdown'>
                    <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' 
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                        Account
                        </a>
                        <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
                        <a class='dropdown-item' href='login.php'>Login</a>
                        <a class='dropdown-item' href='register.php'>Register</a>
                        </li>";
                }



                ?>


            </ul>
        </div>


        </div>
        </div>


    </nav>


    <div class="container">
        <div class="row">
            <div class="jumbotron">
                <div class="row text-center">
                    <h1 class="text-center">My Appointments</h1>
                </div>
            </div>
        </div>
    </div>
    <div id="caleandar">

    </div>


    <script type="text/javascript" src="js/caleandar.js"></script>

    <script>
        <?php

        echo "  var eventsarray = [";




        while ($row = $result->fetch_assoc()) {
            $title = $row['title'];
            $day = $row['date'];
            $id = $row['id'];

            $d = new DateTime($day);
            $d->modify('-1 month');
            $newday = $d->format('Y,m,d');

            //$newday = date('Y,m,d',strtotime($d));

            //  echo "<p>$title, $day, $id</p>";
            echo "{'Date': new Date($newday), 'Title': '$title','Link': '#'},";
        }

        echo "];";

        ?>
        var settings = {
            NavShow: true,
            EventTargetWholeDay: false
        };

        var cal_element = document.getElementById('caleandar');

        caleandar(cal_element, eventsarray, settings);
    </script>


    <div class="container">
        <div class="row">
            <div class="jumbotron">
                <div class="row text-center">
                    <h1 class="text-center">My Training Plans</h1>
                </div>
            </div>
        </div>
    </div>

    <?php

    echo "<div class = 'container'>
                <h1 class='text-center'></h1>";
    echo "<div class='row'>";
    if ($numrows > 0) {
        while ($row = $result2->fetch_assoc()) {

            $pathdata = $row['path'];
            $planid = $row['id'];
            $planname = $row['filename'];




            echo "
                
                <div class= 'col-md-4'>
                <div class='card'>
                <img src='imgs/file.png' style='width:50%; text-align:center;'>
                <div class='card-body'>

                        <h3>$planname</h3>
                
                    <a download='$pathdata' href='uploadedfiles/$pathdata' title='$pathdata'>
                    <button type='button' class='btn btn-primary'>Download</button>
                    </a>
                
            
							
						
                    </div>
                    </div>
                    </div>";
        }
    } else {
        echo "
                <h2>Your application must be approved before recieving a training plan.</h2>
                <p>Haven't sent an application? Click <a href='apply.php'>here</a> to apply.</p>";
    }

    echo "</div>
                </div>";



    ?>
    </div>
    </div>




</body>

</html>