-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 20, 2020 at 05:19 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tconway08`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_tracker`
--

CREATE TABLE `activity_tracker` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `sport` varchar(50) NOT NULL,
  `distance` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `feel` varchar(50) NOT NULL,
  `addinfo` varchar(1000) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_tracker`
--

INSERT INTO `activity_tracker` (`id`, `client_id`, `sport`, `distance`, `time`, `feel`, `addinfo`, `date`) VALUES
(1, 2, 'Cycling', 30, 60, 'Moderate', 'Got a puncture!', '2020-04-20 13:07:59'),
(2, 12, 'Cycling', 2, 24, 'Moderate', 'Felt quite easy', '2020-04-20 14:03:14'),
(3, 13, 'Cycling', 50, 80, 'Hard', 'Got a puncture!', '2020-04-20 14:16:09');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'super', 'super123', 'tconway08@qub.ac.uk');

-- --------------------------------------------------------

--
-- Table structure for table `adminmessages`
--

CREATE TABLE `adminmessages` (
  `client_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminmessages`
--

INSERT INTO `adminmessages` (`client_id`, `date`, `message`) VALUES
(2, '2020-04-20', 'Yeah sure no worries!'),
(13, '2020-04-20', 'Yeah sure!');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `title` varchar(200) NOT NULL,
  `client_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `date`, `title`, `client_id`) VALUES
(1, '2020-04-24', 'John Doe:  Running lesson', 2),
(2, '2020-04-30', 'James Jones:  Swimming lesson', 9),
(3, '2020-05-01', 'Jim Johnstone:  Running lesson', 10),
(4, '2020-05-20', 'Jacob Jones:  Running lesson', 11),
(5, '2020-05-23', 'Bobby Brown:  Running lesson', 13);

-- --------------------------------------------------------

--
-- Table structure for table `client_profiles`
--

CREATE TABLE `client_profiles` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `weight` int(11) NOT NULL,
  `actlevel` varchar(100) NOT NULL,
  `sport` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `client_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_profiles`
--

INSERT INTO `client_profiles` (`id`, `name`, `dob`, `weight`, `actlevel`, `sport`, `description`, `email`, `phone`, `client_id`) VALUES
(1, 'New Account Jonas', '2020-04-08', 70, 'Moderate', 'Cycling', 'q2iejaidjawd', 'new@email.com', '9248924384', '1'),
(2, 'John Doe', '1998-03-13', 70, 'Moderate', 'Swim', 'hello', 'new1@email.com', '82328784', '2'),
(3, 'Jane Jones', '1995-10-06', 70, 'Light', 'Swim', 'ewdawd', 'new3@email.com', '82378432', '3'),
(4, 'Barry Apples', '2000-06-21', 58, 'Light', 'Swim', 'dadafdawad', 'new4@email.com', '9334833', '4'),
(5, 'James Jones', '2007-06-14', 70, 'Moderate', 'Cycling', 'Completed 3 triathalons. Would like to improve my cycling.', 'account1@email.com', '83748437', '9'),
(6, 'Jim Johnstone', '2009-06-19', 70, 'Moderate', 'Running', 'Would like to improve my running technique', 'mynewaccount@email.com', '83784343', '10'),
(7, 'Jacob Jones', '2005-02-09', 70, 'Moderate', 'Running', 'Id like to improve my running technique', 'account@email.com', '27827487343', '11'),
(8, 'Mac Ross', '2003-06-11', 70, 'Moderate', 'Cycling', 'Want to improve my cycling distances', 'newaccount@Email.com', '9838748274', '12'),
(9, 'Bobby Brown', '2007-07-12', 70, 'Moderate', 'Running', 'Id like to increase my distance', 'new2@email.com', '2342874184', '13');

-- --------------------------------------------------------

--
-- Table structure for table `client_schedule`
--

CREATE TABLE `client_schedule` (
  `client_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `date`, `title`) VALUES
(1, '2020-04-23', 'Belfast 10k'),
(2, '2020-04-25', 'Derry Triathalon'),
(3, '2020-04-29', 'Lough Neagh 5k swim'),
(4, '2020-07-01', 'Belfast marathon'),
(5, '2020-05-05', 'Belfast 5k'),
(6, '2020-06-11', 'Belfast half '),
(7, '2020-04-20', ' newry half marathon');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `client_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `message` varchar(100) NOT NULL,
  `client_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`client_id`, `date`, `message`, `client_name`) VALUES
(2, '2020-04-20', 'Hey could i get an appointment on the 25th instead please?', 'John Doe'),
(13, '2020-04-20', 'Hi can i get an appointment for the 6th of may', 'Bobby Brown'),
(13, '2020-04-20', 'Cool thanks!', 'Bobby Brown');

-- --------------------------------------------------------

--
-- Table structure for table `upload_plan`
--

CREATE TABLE `upload_plan` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `path` varchar(100) NOT NULL,
  `filetype` varchar(100) NOT NULL,
  `filename` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_plan`
--

INSERT INTO `upload_plan` (`id`, `client_id`, `path`, `filetype`, `filename`) VALUES
(1, 2, 'Training plan week 1', 'application/pdf', 'Training plan week 1'),
(2, 9, 'Week 1 training plan', 'application/pdf', 'Week 1 training plan'),
(3, 10, 'Training plan week 1', 'application/pdf', 'Training plan week 1'),
(4, 11, 'Training plan week 1', 'application/pdf', 'Training plan week 1'),
(5, 12, 'Training plan week 1', 'application/pdf', 'Training plan week 1'),
(6, 13, 'Training plan week 1', 'application/pdf', 'Training plan week 1');

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

CREATE TABLE `user_accounts` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `signup` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_accounts`
--

INSERT INTO `user_accounts` (`id`, `username`, `password`, `email`, `name`, `phone`, `address`, `signup`) VALUES
(1, 'newaccount1', 'password', 'new@email.com', 'New Account Jonas', '9248924384', '69 Bank Street, Flat 0/1', '2020-04-20 12:37:53'),
(2, 'newaccount2', 'password', 'new1@email.com', 'John Doe', '82328784', '23 isajda', '2020-04-20 12:54:31'),
(3, 'newaccount3', 'password', 'new3@email.com', 'Jane Jones', '82378432', '22 Seaview', '2020-04-20 12:55:42'),
(4, 'newaccount4', 'password', 'new4@email.com', 'Barry Apples', '9334833', 'University Avenue', '2020-04-20 12:57:04'),
(5, 'newaccount5', 'password', 'new5@email.com', 'Katy May', '76347642', 'University Avenue', '2020-04-20 12:58:11'),
(6, 'newaccount6', 'password', 'new6@email.com', 'Henry Black', '74634648652', '69 Bank Street, Flat 0/1', '2020-04-20 12:59:35'),
(7, 'newaccount6', 'password', 'new6@email.com', 'Margaret Faye', '228748732', 'University Avenue', '2020-04-20 13:01:07'),
(8, 'myaccount', 'password', 'myaccount@email.com', 'Timothy Conway', '2874842442', '213 University st', '2020-04-20 13:25:04'),
(9, 'mynewaccount1', 'password', 'account1@email.com', 'James Jones', '83748437', '23 University St', '2020-04-20 13:28:21'),
(10, 'mynewaccount2', 'password', 'mynewaccount@email.com', 'Jim Johnstone', '83784343', '42 Uni St', '2020-04-20 13:37:47'),
(11, 'account1', 'password', 'account@email.com', 'Jacob Jones', '27827487343', '32 Uni st', '2020-04-20 13:46:00'),
(12, 'new1', 'password', 'newaccount@Email.com', 'Mac Ross', '9838748274', '23 University St', '2020-04-20 13:57:04'),
(13, 'new2', 'password', 'new2@email.com', 'Bobby Brown', '2342874184', '42 Uni St', '2020-04-20 14:07:16'),
(14, 'SamSteele', 'password', 'ssteele16@qub.ac.uk', 'Samuel Steele', '9348589057', '111 Imaginary land', '2020-04-20 14:23:42');

-- --------------------------------------------------------

--
-- Table structure for table `user_applications`
--

CREATE TABLE `user_applications` (
  `id` int(11) NOT NULL,
  `dob` date NOT NULL,
  `weight` int(11) NOT NULL,
  `actlevel` varchar(20) NOT NULL,
  `sport` varchar(20) NOT NULL,
  `description` varchar(250) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_applications`
--

INSERT INTO `user_applications` (`id`, `dob`, `weight`, `actlevel`, `sport`, `description`, `user_id`) VALUES
(30, '2020-04-08', 70, 'Light', 'Swim', 'I have completed 3 triathalons but would like to improve my distance swimming', 5),
(31, '1998-06-17', 70, 'Moderate', 'Running', 'Recovering from an ankle injury! Would like to get better at running.', 6),
(32, '2020-04-07', 70, 'Moderate', 'Cycling', 'Hello I would like to up my cycling distance', 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_tracker`
--
ALTER TABLE `activity_tracker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_profiles`
--
ALTER TABLE `client_profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upload_plan`
--
ALTER TABLE `upload_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_applications`
--
ALTER TABLE `user_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `use_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_tracker`
--
ALTER TABLE `activity_tracker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `client_profiles`
--
ALTER TABLE `client_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `upload_plan`
--
ALTER TABLE `upload_plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_accounts`
--
ALTER TABLE `user_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user_applications`
--
ALTER TABLE `user_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_applications`
--
ALTER TABLE `user_applications`
  ADD CONSTRAINT `use_id` FOREIGN KEY (`user_id`) REFERENCES `user_accounts` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
